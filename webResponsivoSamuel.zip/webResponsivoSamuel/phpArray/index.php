<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>Fotos em carrossel</title>
</head>
<body>
    <?php include("../menu.php");?>

    <div class="container-fluid p-5 bg-secondary text-white text-center">
        <h2>Tela para exibir imagens em galeria e carrossel</h2>
    </div>

    <?php include("carrossel.php");?>
    <?php include("galeria.php");?>
</body>
</html>