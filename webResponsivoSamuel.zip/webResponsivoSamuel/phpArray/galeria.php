<div class="container text-center" >

  <h1>Galeria</h1>
  <p>A forma das imagens exibida aqui é de galeria</p>
  <p></p>
  <div class="row">

        <?php
            $dir = 'C:/wamp64/www/webResponsivoSamuel/phpArray/imagens';
            $files = scandir($dir);
            foreach($files as $file){
                if($file != "." AND $file != "..") {
                    echo "<div class='col'>";
                        echo "<div class='img-thumbnail m-1 p-1'>";
                            echo "<a href='imagens/$file'>";
                            echo "<img src='imagens/$file' style='width:100%'>";
                            echo "</a>";
                            echo "<div class='caption'>";
                                echo "<p>$file</p>";
                            echo "</div>";
                        echo "</div>";
                    echo "</div>";
                }
            }
        ?>

    </div>
</div>    