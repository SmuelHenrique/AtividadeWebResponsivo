<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>Pagina Principal</title>
</head>
<body>

    <?php include ("menu.php"); ?>

    <div class="container-fluid mt-3">
        <h3> Atividade do Aluno Samuel Henrique sobre Web Responsivo </h3>
        <br>
        <h3>Sistemas Web Responsivos</h3>
        <h4>com PHP, MySQL, Javascript, CSS e Bootstrap</h4>
    </div>
    
</body>
</html>