<nav class="navbar navbar-expand-sm bg-dark navbar-dark fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="/webResponsivoSamuel/">Home</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
      <ul class="navbar-nav">

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Java Script</a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="/webResponsivoSamuel/JavaScript/dobrarReceita">Dobrar receita</a></li>
            <li><a class="dropdown-item" href="/webResponsivoSamuel/JavaScript/PasseiDeAno">Conferir se passei</a></li>
            <li><a class="dropdown-item" href="/webResponsivoSamuel/JavaScript/possoAposentar">Aposentadoria</a></li>
            <li><a class="dropdown-item" href="/webResponsivoSamuel/JavaScript/simuladorInvestimento">Investir</a></li>
          </ul>
        </li> 

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">PHP</a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="/webResponsivoSamuel/phpReceita">01 - Receita</a></li>
            <li><a class="dropdown-item" href="/webResponsivoSamuel/phpTabela">02 - TAbela de multiplicação</a></li>
            <li><a class="dropdown-item" href="/webResponsivoSamuel/phpArray">03 - Imagens</a></li>
            <li><a class="dropdown-item" href="/webResponsivoSamuel/phpBancoDados/CadastroPremio">04.1 - Banco de dados Cadastro - Premio</a></li>
            <li><a class="dropdown-item" href="/webResponsivoSamuel/phpBancoDados/CadastroEnxadrista">04.2 - Banco de dados Cadastro - Enxadrista</a></li>
            <li><a class="dropdown-item" href="/webResponsivoSamuel/phpBancoDados/Principal">04 - Banco de dados Visualizar, Editar, Excluir</a></li>
            <li><a class="dropdown-item" href="#">Continua ...</a></li>
          </ul>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Para o Futuro</a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="https://www.w3schools.com/nodejs/nodejs_get_started.asp">Node.js</a></li>
            <li><a class="dropdown-item" href="https://www.w3schools.com/react/react_getstarted.asp">React</a></li>
          </ul>
        </li>

      </ul>
    </div>
  </div>
</nav>
<br><br>