<!DOCTYPE html>
<html lang="en">
<head>
    <script src="javaScript.js"></script>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="estilo.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>Passei de Ano</title>
</head>
<body>
    <?php include("../../menu.php") ?>

    <div id="texto" class="main p-5 mt-3 w3-container w3-border w3-round-xlarge div-no-centro">
        <h2>Tela para descobrir se posso aposentar ou não</h2>
        <label for="nome">nome: </label>
            <br>
            <input type="text" id="nome" class="redondo">
            <br>
        <label for="idade">idade: </label>
            <br>
            <input type="number" id="idade" class="redondo">
            <br>
        <label for="cont">Tempo de Contribuiçao: </label>
            <br>
            <input type="number" id="cont" class="redondo">
            <br>
        <label for="sexo"></label>
            <input type="radio" id="fem" name="sexo" value="feminino">
            <label for="fem"> Feminino</label>
            <br>    
            <input type="radio" id="masc" name="sexo" value="masculino">
            <label for="mas"> Masculino</label>
            <br>
        <input type="button" id="botao" class="btn btn-secondary m-1" onclick="Calcular()" value="Botao">
    </div>
</body>
</html>