function Calcular(){
    let nome = document.getElementById("nome").value;
    let idade = document.getElementById("idade").value;
    idade = parseInt(idade);
    let cont = document.getElementById("cont").value;
    cont = parseInt(cont);
    
    if(document.getElementById("nome").value == "" ||
            isNaN(idade) || isNaN(cont))
        {
            alert("Insira valores válidos")
        } else{
            if(document.getElementById("fem").checked){
                if(idade >= 57 && cont >= 30){
                    document.getElementById("texto").innerHTML = 
                        nome + ", Parabéns você já pode aposentar";
                } else {
                    document.getElementById("texto").innerHTML = 
                        nome + ", Infelizmente você não pode aposentar";
                }

            } else if(document.getElementById("masc").checked){
                if(idade >= 62 && cont >= 35){
                    document.getElementById("texto").innerHTML = 
                        nome + ", Parabéns você já pode aposentar";
                } else {
                    document.getElementById("texto").innerHTML = 
                        nome + ", Infelizmente você não pode aposentar";
                }
            }
        }
}