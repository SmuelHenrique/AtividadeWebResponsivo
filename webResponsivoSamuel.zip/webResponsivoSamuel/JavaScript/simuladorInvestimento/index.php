<!DOCTYPE html>
<html lang="en">
<head>
    <script src="javaScript.js"></script>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="estilo.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>Simulador de investimentos</title>
</head>
<body>
    <?php include("../../menu.php")?>
    <div class="main p-5 mt-3 w3-container w3-border w3-round-xlarge div-no-centro">
        <h3>Site para clacular investimentos</h3>
        <form>
            <label for="">Capital: </label> <br>
            <input type="number" id="capital" class="redondo"> <br> <br>

            <label for="">Juros ao ano: </label> <br>
            <input type="number" id="juros" class="redondo">
            <label for="">%</label>
            <br> <br>

            <label for="">Tempo em anos investido: </label> <br>
            <input type="number" id = "tempo" class="redondo"> <br> <br>

            <input type="button" class="btn btn-secondary m-1" onclick="Calcular()" value="Calcular">

        </form>
    </div>
</body>
</html>