function Calcular() {
    
    let c = document.getElementById("capital").value;
    c = parseFloat(c);
    let j = document.getElementById("juros").value;
    j = parseFloat(j);
    let t = document.getElementById("tempo").value;
    t = parseFloat(t);
    let m = c * (Math.pow(1 + j, t));

    if (isNaN(c) || isNaN(j) || isNaN(t)) {
        alert("Insira valores nos campos, e valores válidos")
    } else {
        final = m.toFixed(2);
        alert("O seu montante final é de: " + final);
    }
}