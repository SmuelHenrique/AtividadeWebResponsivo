<!DOCTYPE html>
<html lang="en">
<head>
    <script src="javaScript.js"></script>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="estilo.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>Calcular se passei de ano</title>
</head>
<body>

 <?php include("../../menu.php") ?>
<div class="main p-5 mt-3 w3-container w3-border w3-round-xlarge div-no-centro">
    <div id="texto" class="div-no-centro">
        <h2>Tela para descobrir se passei ou não de ano</h2>
        <label for="nome" >Nome: </label> <br>
                <input type="text" id="nome" class="redondo"> <br> <br> <br>
            <!-- Notas -->
                <label for="Nota 1" >Nota 1: </label> <br>
                    <input type="number" id="n1" class="redondo"> <br>

                <label for="Peso 1">Peso 1: </label> <br>
                    <input type="number" id="p1" class="redondo"> <br><br>

                <label for="Nota 2">Nota 2: </label> <br>
                    <input type="number" id="n2" class="redondo"> <br>

                <label for="Peso 2">Peso 2: </label> <br>
                    <input type="number" id="p2" class="redondo"> <br><br>

                <label for="Nota 3">Nota 3: </label> <br>
                    <input type="number" id="n3" class="redondo"> <br>

                <label for="Peso 3">Peso 3: </label> <br>
                    <input type="number" id="p3" class="redondo"> <br><br>

                <label for="Nota 4">Nota 4: </label> <br>
                    <input type="number" id="n4" class="redondo"> <br>

                <label for="Peso 4">Peso 4: </label> <br>
                    <input type="number" id="p4" class="redondo"> <br><br>
            <!-- Fim das Notas -->
            
            <label for="frequencia"> Frequência: </label> <br>
                <input type="number" id="fr" class="redondo"> <br><br>

            <button id="botao" value="Calcular" class="btn btn-secondary m-1" onclick="Verificar()">Calcular</button>
    </div> 
</div>    
</body>
</html>