function Verificar(){
    let n1 = document.getElementById("n1").value;
    let n2 = document.getElementById("n2").value;
    let n3 = document.getElementById("n3").value;
    let n4 = document.getElementById("n4").value;

    let p1 = document.getElementById("p1").value;
    p1 = parseInt(p1);
    let p2 = document.getElementById("p2").value;
    p2 = parseInt(p2);
    let p3 = document.getElementById("p3").value;
    p3 = parseInt(p3);
    let p4 = document.getElementById("p4").value;
    p4 = parseInt(p4);

    if(document.getElementById("nome").value == "" ||
        n1 == ""  || n2 == "" || n3 == ""  || n4 == ""  ||
        isNaN(p1) || isNaN(p2)|| isNaN(p3) || isNaN(p4) ||
        document.getElementById("fr").value == "")
        {
            alert("Complete todos os Campos");
    } else{
        VerificarPeso(p1, p2, p3, p4, n1, n2, n3, n4);
    }    
}

function VerificarPeso(p1, p2, p3, p4, n1, n2, n3, n4){
    if (p1 + p2 + p3 + p4 != 10) {
        alert("O valor dos pesos deve totalizar 10");
    } else {
        VerificarNotas(p1, p2, p3, p4, n1, n2, n3, n4);
    }
}

function VerificarNotas(p1, p2, p3, p4, n1, n2, n3, n4){
    if (n1 <= 10 && n1 >=0 && n2 <= 10 && n2 >=0 && n3 <= 10 && n3 >=0 && n4 <= 10 && n4 >=0) {
        CallcularPasse(p1, p2, p3, p4, n1, n2, n3, n4);
    } else {
        alert("As notas devem estar entre 0 e 10")
    }
}

function CallcularPasse(p1, p2, p3, p4, n1, n2, n3, n4){
    if(document.getElementById("fr").value < 75){
        alert("Sinto lhe dizer " + document.getElementById("nome").value + ", você reprovou por falta" )
    } else {
        if( ((n1 * p1) + ( n2 * p2) + (n3 * p3) + (n4 * p4)) / (p1 + p2 + p3 + p4) < 6 ){
            alert("Sinto lhe dizer " + document.getElementById("nome").value + ", você reprovou por nota")
        } else {
                alert("Meus parabéns " + document.getElementById("nome").value + ", você foi aprovado com media de: " 
                    + ((n1 * p1) + ( n2 * p2) + (n3 * p3) + (n4 * p4)) / (p1 + p2 + p3 + p4) )
            }
    }    
}

