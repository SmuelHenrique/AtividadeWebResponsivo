<!DOCTYPE html>
<html lang="en">
<head>
    <script src="javaScript.js"></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="estilo.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>Dobrar Receita</title>
</head>
<body>

    <?php include("../../menu.php"); ?>

    <div class="div-no-centro">
    

        <div id="Receita" class="main p-5 mt-3 w3-container w3-border w3-round-xlarge">
            <h2>Tela para calcular ingredientes para uma nova receita</h2>
            <h3>Receita Original</h3>
            <ul>
                <li>3 ovos inteiros</li>
                <li>2 xícaras (chá) de açúcar</li>
                <li>2 xícaras (chá) de fubá</li>
                <li>3 colheres (sopa) de farinha de trigo</li>
                <li>1/2 copo (americano) de óleo</li>
                <li>1 copo (americano) de leite</li>
                <li>1 colher (sopa) de fermento em pó</li>
            </ul>

            <form>
                <label for="quant" class="m-1">Quantidade que deseja multiplicar: </label>
                <br>
                <input type="number" id="quant" required class="m-1">
                <br>
                <br>
                <input type="button" value="Calcular" class="btn btn-secondary m-1" onclick="Calcular()">
            </form>
        </div>

        <div id="resul" class="main p-5 mt-3 w3-container w3-border w3-round-xlarge" style="display: none;">
            
        </div>
    </div>    
</body>
</html>