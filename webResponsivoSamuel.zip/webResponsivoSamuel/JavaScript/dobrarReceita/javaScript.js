function Calcular(){
    mult = document.getElementById("quant").value;
    mult = parseInt(mult);

    // Atualizar valor
    let ovoA = mult * 3;
    let acucarA = mult * 2;
    let fubaA = mult * 2;
    let farinhaA = mult * 3;
    let leiteA = mult * 1;
    let fermentoA = mult * 1;

    if ( isNaN(mult) ) {
        alert("Preencha com valores válidos");
    } else {
        
        if (mult % 2 == 0) {
            let i = mult / 2;

            let div = document.getElementById("resul").innerHTML = 
            "<h3>Receita Atualizada</h3>" + 
            "<ul>" +
                "<li>" + ovoA + " ovos inteiros" + "</li>" +
                "<li>" + acucarA + " xícaras (chá) de açúcar" + "</li>" +
                "<li>" + fubaA + " xícaras (chá) de fubá" + "</li>" +
                "<li>" + farinhaA + " colheres (sopa) de farinha de trigo" + "</li>" +
                "<li>" + i + " copos (americano) de óleo" + "</li>" + 
                "<li>" + leiteA + " copo (americano) de leite" + "</li>" +
                "<li>" + fermentoA + " colher (sopa) de fermento em pó" + "</li>" +
            "</ul>" + 
            "<input type='button' value='Voltar' class='btn btn-secondary m-1' onclick='Voltar()'>"
            document.getElementById("Receita").style.display = "none";
            document.getElementById("resul").style.display = "block";
        } else {
            let i = mult / 2;
            i = i.toFixed(0) - 1;

            let div = document.getElementById("resul").innerHTML = 
            "<h3>Receita Atualizada</h3>" + 
            "<ul>" +
                "<li>" + ovoA + " ovos inteiros" + "</li>" +
                "<li>" + acucarA + " xícaras (chá) de açúcar" + "</li>" +
                "<li>" + fubaA + " xícaras (chá) de fubá" + "</li>" +
                "<li>" + farinhaA + " colheres (sopa) de farinha de trigo" + "</li>" +
                "<li>" + i + " " + mult % 2 + "/" + 2 + "copo (americano) de óleo" + "</li>" + 
                "<li>" + leiteA + " copo (americano) de leite" + "</li>" +
                "<li>" + fermentoA + " colher (sopa) de fermento em pó" + "</li>" +
            "</ul>" +
            "<input type='button' value='Voltar' class='btn btn-secondary m-1' onclick='Voltar()'>"
            document.getElementById("Receita").style.display = "none";
            document.getElementById("resul").style.display = "block";
        }
    }
}

function Voltar(){
    document.getElementById("Receita").style.display = "block";
    document.getElementById("resul").style.display = "none";
}