<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>Tabela de multiplicação</title>
</head>
<body>
    <?php include("../menu.php"); ?>

    <div class="container-fluid p-5 bg-secondary text-white text-center">
        <h1>Laços Encadeados</h1>
        <p>Laços encadeados, ou aninhados, são laços dentro de laços</p> 
    </div>

    <div class="container-fluid mt-3 text-center ">
        <h2>Tabuadas do 1 ao 100</h2>
        <div class="row">
            <?php 
                for($i=1; $i <= 100; $i++){
                    echo "<div class='col p-3 m-2'><div class='card' style='width:10rem;'><div class='card-header'>Tabuada do " . $i . "</div><div class='card-body'>";
                    for($k=1; $k<=10; $k++){
                        echo $i . " X ". $k . " = " . ($i*$k) . "<br>";
                    }
                    echo "</div></div></div>";
                }
            ?>
        </div>
    </div>
</body>
</html>