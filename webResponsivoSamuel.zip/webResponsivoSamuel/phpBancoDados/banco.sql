create database xadrez;

use xadrez;

create table premios(
    nomePremio varchar(100) PRIMARY KEY,
    anoPremio integer not null
    
);

create table enxadrista(
    nomeEnxadrista varchar(100) PRIMARY KEY,
    idade integer not null,
    nacionalidade varchar(100) not null
);

create table enxadrista_premio(
	nomeEnxadrista varchar(100),
    nomePremio varchar(100),
    FOREIGN KEY (nomeEnxadrista) REFERENCES enxadrista(nomeEnxadrista),
    FOREIGN KEY (nomePremio) REFERENCES premios(nomePremio)
);

INSERT INTO premios(nomePremio, anoPremio)
	values("Campeão Mundial de 1975", 1975);
    
INSERT INTO premios(nomePremio, anoPremio)
	values("Campeão Mundial de 2013", 2013);
    
INSERT INTO enxadrista()
	values("Anatoly Karpov", 72, "Russo");
    
INSERT INTO enxadrista()
	values("Magnus Carlsen", 32, "Norueguês");
    
insert into enxadrista_premio()
	values("Anatoly Karpov", "Campeão Mundial de 1975");
    
insert into enxadrista_premio()
 	values("Magnus Carlsen", "Campeão Mundial de 2013");