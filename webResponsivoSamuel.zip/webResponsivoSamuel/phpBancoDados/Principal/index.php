<!DOCTYPE html>
<html lang="en">
<head>
<title>Sistemas Web Responsivos</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    
<?php include("../../menu.php"); ?>

<div class="container-fluid p-5 bg-secondary text-white text-center">
  <h1>Banco de Dados - Editar</h1>
  <p>Lista cliclável com função Editar</p> 
</div>
  
<div class="container-fluid mt-3">
  <h1>Minha Lista</h1>
  <p>Abaixo uma lista com todos os itens da tabela.</p>
    

  
  
<div class="list-group">
  <?php
    include("../conexaoBanco.php");
    try {
      $sth = $dbh->prepare('SELECT enxadrista.nomeEnxadrista, enxadrista.nacionalidade, premios.nomePremio from enxadrista 
        inner join enxadrista_premio on enxadrista_premio.nomeEnxadrista = enxadrista.nomeEnxadrista
        inner join premios on premios.nomePremio = enxadrista_premio.nomePremio');
      $sth->execute();
      $result = $sth->fetchAll(PDO::FETCH_ASSOC);
      if(!empty($result)) {
        foreach($result as $row) {
          echo "<a href='detalhe.php?nomeEnxadrista=".$row["nomeEnxadrista"]."' class='list-group-item list-group-item-action'>"
            .$row["nomeEnxadrista"] . " - " . $row["nacionalidade"] . " - " . $row["nomePremio"] . " ";
          echo "</a>";
        }
      } 
      $dbh = null;
    } catch (PDOException $e) {
      print "Error!: " . $e->getMessage();
      die();
    }
  ?>
</div>

</div>

<br><b>
</body>
</html>

