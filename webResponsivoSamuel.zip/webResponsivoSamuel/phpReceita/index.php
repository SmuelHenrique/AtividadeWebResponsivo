<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>Receita</title>
</head>
<body>
    
    <?php include("../menu.php");?>

    <div class="container-fluid p-5 bg-secondary text-white text-center">
        <h1>Tela para multiplicar receita</h1>
    </div>

    <div class="container-fluid mt-3">
        <h1>Dobrar Receita</h1>
        <p>Neste exemplo, recebemos um número e multiplicamos cada ingrediente da receita.</p>
        
        <h5>Mousse de limão</h5>

        <br>1 lata de leite condensado
        <br>1 lata de creme de leite
        <br>1,5 xícara de suco de limão

        <form action="action.php" method="post">
            Multiplicar receita por:
            <input type="number" id="num" name="num"> <br>
            <input type="submit" value="Multiplicar Receita" class="text-center">
        </form>
    </div>
</body>
</html>